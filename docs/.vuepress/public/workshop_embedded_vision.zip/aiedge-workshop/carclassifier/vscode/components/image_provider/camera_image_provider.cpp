#include "camera_image_provider.h"
#include "esp_eye_camera_config.h"

CameraImageProvider::CameraImageProvider() :
    m_init(false)
{
}

const uint8_t* CameraImageProvider::get(int size)
{
    if (!m_init) {
        if (!esp_eye_camera_init()) {
            printf("Camera error: initialize failed\r\n");
            return nullptr;
        }
        m_init = true;
    }

    camera_fb_t *fb = esp_camera_fb_get();
    if (fb == nullptr) {
        printf("Camera error: failed to capture image\r\n");
        return nullptr;
    }

    const int image_size = fb->width * fb->height * 3;
    if (image_size != size) {
        printf("Camera error: image size (%d) is different from expected size (%d)\r\n", image_size, size);
        return nullptr;
    }

    return fb->buf;
}
