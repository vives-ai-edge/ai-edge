#include "serial_image_provider.h"
#include <stdlib.h>

#define LED_WHITE   GPIO_NUM_22

SerialImageProvider::SerialImageProvider(EspSerialPort* serial_port) :
    m_serial_port(serial_port),
    m_buffer(nullptr)
{
}

const uint8_t* SerialImageProvider::get(int size)
{
    uint8_t pre0=0, pre1;

    // wait for preamble
    do {
        pre1 = pre0;
        m_serial_port->read_block(&pre0, 1);
    } while(pre0 != 0xbe || pre1 != 0xef);

    // allocate buffer if not yet allocated
    if (!m_buffer)
        m_buffer = static_cast<uint8_t*>(malloc(size));

    // read image data
    if (m_buffer)
        m_serial_port->read_block(m_buffer, size);

    return m_buffer;
}
