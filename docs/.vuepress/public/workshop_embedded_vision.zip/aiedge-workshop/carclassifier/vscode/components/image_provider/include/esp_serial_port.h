#ifndef ESP_SERIAL_PORT_H
#define ESP_SERIAL_PORT_H

#include "driver/uart.h"

class EspSerialPort
{
public:
    void init(int baud_rate);

    void write(const void* data, int len);

    int read(void* data, int len);

    /*
     *  Wait until len number of bytes are received
     */
    void read_block(void* data, int len);

    /*
     *  Write the output of a classifier and the inference time
     */
    void write_result(uint8_t label, uint32_t time);
};

#endif /* ESP_SERIAL_PORT_H */
