#include "esp_serial_port.h"
#include "driver/gpio.h"

#define BUF_SIZE                128
#define UART_PORT_NUM           0
#define UART_GPIO_PIN_TXD       1
#define UART_GPIO_PIN_RXD       3

void EspSerialPort::init(int baud_rate)
{
    uart_config_t uart_config = {
        .baud_rate = baud_rate,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .rx_flow_ctrl_thresh = 122,
        .source_clk = UART_SCLK_APB,
    };
    const int intr_alloc_flags = 0;

    ESP_ERROR_CHECK(uart_driver_install(UART_PORT_NUM, BUF_SIZE * 2, 0, 0, NULL, intr_alloc_flags));
    ESP_ERROR_CHECK(uart_param_config(UART_PORT_NUM, &uart_config));
    ESP_ERROR_CHECK(uart_set_pin(UART_PORT_NUM, UART_GPIO_PIN_TXD, UART_GPIO_PIN_RXD, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
}

void EspSerialPort::write(const void* data, int len)
{
    uart_write_bytes(UART_PORT_NUM, (const char*)data, len);
}

int EspSerialPort::read(void* data, int len)
{
    return uart_read_bytes(UART_PORT_NUM, (uint8_t*)data, len, 20 / portTICK_PERIOD_MS);
}

void EspSerialPort::read_block(void* data, int len)
{
    unsigned char* p = reinterpret_cast<unsigned char*>(data);
    int read_bytes = 0;

    do {
        const int res = this->read(&p[read_bytes], len - read_bytes);
        if (res > 0)
            read_bytes += res;
    } while (read_bytes < len);
}

void EspSerialPort::write_result(const uint8_t class_output, const uint32_t time)
{
    const uint16_t preamble = 0xbeef;

    this->write(&preamble, sizeof(preamble));
    this->write(&time, sizeof(time));
    this->write(&class_output, sizeof(class_output));
}