#ifndef SERIAL_IMAGE_PROVIDER_H
#define SERIAL_IMAGE_PROVIDER_H

#include "image_provider.h"
#include "esp_serial_port.h"

class SerialImageProvider: public ImageProvider
{
public:
    SerialImageProvider(EspSerialPort* serial_port);

    const uint8_t* get(int size) override;

private:
    EspSerialPort* m_serial_port;
    uint8_t* m_buffer;
};

#endif /* SERIAL_IMAGE_PROVIDER_H */
