#ifndef CARCLASSIFIER_H
#define CARCLASSIFIER_H

// Model input dimensions
constexpr int kNumCols = 96;
constexpr int kNumRows = 96;
constexpr int kNumChannels = 3;
constexpr int kMaxImageSize = kNumCols * kNumRows * kNumChannels;

extern const unsigned char carclassifier_tflite[];
extern const unsigned int carclassifier_tflite_len;

#endif /* CARCLASSIFIER_H */