// FreeRTOS and ESP includes
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"

// TFlite Micro includes
#include "tensorflow/lite/micro/micro_error_reporter.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/schema/schema_generated.h"

// Camera module
#include "camera_image_provider.h"
#include "esp_serial_port.h"
#include "serial_image_provider.h"

// Header file for our model
#include "carclassifier.h"

// Constants
const gpio_num_t g_led_red = GPIO_NUM_21;
const gpio_num_t g_led_white = GPIO_NUM_22;
tflite::MicroInterpreter* g_interpreter = nullptr;


bool setup()
{
    // Setup LED
    gpio_set_direction(g_led_red, GPIO_MODE_OUTPUT);

    // Setup Logging
    // This is required for TFLite Micro
    static tflite::MicroErrorReporter micro_error_reporter;

    // Load Model
    // The model is defined as a C array, which we generated in the notebook
    const tflite::Model* model = ::tflite::GetModel(carclassifier_tflite);
    if (model->version() != TFLITE_SCHEMA_VERSION) {
        printf(
            "Model provided is schema version %d not equal to supported version %d.\n",
            model->version(),
            TFLITE_SCHEMA_VERSION
        );
        return false;
    }

    // Operations Resolver
    // The model definition defines which operation to run and in what order, but this resolver links operations with the correct code to run.
    // TFLite Micro contains a resolver with all operations, but in order to limit code memory and compile time,
    // we can use a MutableOpResolver and specify which operations will be used.
    static tflite::MicroMutableOpResolver<4> resolver;
    resolver.AddConv2D();
    resolver.AddDepthwiseConv2D();
    resolver.AddAveragePool2D();
    resolver.AddLogistic();
    
    // Allocate Memory
    // Instead of dynamically allocating memory, TFLite Micro works with a static memory pool.
    // All data necessary to run the model will be stored in here.
    // One optimization is to reduce the arena_size to get it as small as possible, whilst still being able to run the model.
    constexpr int tensor_arena_size = 140 * 1024;
    static uint8_t tensor_arena[tensor_arena_size];

    // Interpreter
    // Finally we combine all the objects above into a single TFLite interpreter object.
    static tflite::MicroInterpreter interpreter(
        model,
        resolver,
        tensor_arena,
        tensor_arena_size,
        &micro_error_reporter
    );

    g_interpreter = &interpreter;

    // Allocate Tensors
    // Once the interpreter is build, we can try to allocate memory in our arena, to check whether we reserved enough memory.
    if (interpreter.AllocateTensors() != kTfLiteOk) {
        printf("Allocate tensors failed\n");
        return false;
    }

    return true;
}


void main_task_camera(void)
{   
    // Camera image provider
    CameraImageProvider image_provider;

    // Input & Output
    // These are the objects which we access in order to provide input and read the output from the model.
    TfLiteTensor* input = g_interpreter->input(0);
    TfLiteTensor* output = g_interpreter->output(0);

    // We want to process camera images forever
    while (true) {

        // Get image from provider
        const uint8_t* image_buffer = image_provider.get(kMaxImageSize);
        if (!image_buffer) {
            printf("Failed to capture image\n");
            return;
        }

        // Provide input
        // The data field is a union type, which allows you to pass data as different types.
        // When quantizing our model we specified the inputs to be int8 values and thus here we access the ".int8" buffer.
        // We also need to transform the image from [0,255] uint8 to [-128,127] int8.
        for (int i=0; i<kMaxImageSize; ++i) {
            input->data.int8[i] = image_buffer[i] - 128;
        }

        // Run Model
        int64_t start_time = esp_timer_get_time();
        if (kTfLiteOk != g_interpreter->Invoke()) {
            printf("Invoke failed\n");
            return;
        }
        int64_t stop_time = esp_timer_get_time();

        // Get output
        // Similarly to the input, the output data field is also a union type, which we access with the "int8" accessor.
        // We also need to transform the output probability from [-128,127] int8 to [0,1] float
        float output_probability = (output->data.int8[0] + 128.) / 255.;
        bool output_car = output_probability > 0.5;

        // Print result and inference time
        printf(
            "%s  (%.2f %%) [%.2f ms]\n",
            output_car ? "Car" : "No Car",
            output_probability * 100,
            (stop_time - start_time) / 1000.0
        );

        // Set LED
        gpio_set_level(g_led_red, output_car ? 1 : 0);

        vTaskDelay(1);
    }
}


void main_task_serial(void)
{
    // Serial image provider
    EspSerialPort serial;
    serial.init(115200);

    SerialImageProvider image_provider(&serial);
    
    // Input & Output
    // These are the objects which we access in order to provide input and read the output from the model.
    TfLiteTensor* input = g_interpreter->input(0);
    TfLiteTensor* output = g_interpreter->output(0);

    // We want to process camera images forever
    while (true) {

        // Get image from provider
        const uint8_t* image_buffer = image_provider.get(kMaxImageSize);
        if (!image_buffer) {
            printf("Failed to capture image\n");
            return;
        }

        // Provide input
        // The data field is a union type, which allows you to pass data as different types.
        // When quantizing our model we specified the inputs to be int8 values and thus here we access the ".int8" buffer.
        // We also need to transform the image from [0,255] uint8 to [-128,127] int8.
        for (int i=0; i<kMaxImageSize; ++i) {
            input->data.int8[i] = image_buffer[i] - 128;
        }

        gpio_set_level(g_led_white, 0);

        // Run Model
        const int64_t start_time = esp_timer_get_time();
        if (kTfLiteOk != g_interpreter->Invoke()) {
            printf("Invoke failed\n");
            return;
        }
        const int64_t stop_time = esp_timer_get_time();

        // Get output
        // Similarly to the input, the output data field is also a union type, which we access with the "int8" accessor.
        // We also need to transform the output probability from [-128,127] int8 to [0,1] float
        float output_data = (output->data.int8[0] + 128.) / 255.;
        const uint8_t output_car = output_data > 0.5 ? 1 : 0;

        // Send back result
        serial.write_result(output_car, stop_time - start_time);

        vTaskDelay(1);
    }
}


// Main entry point of ESP
extern "C" void app_main()
{
    // White LED on during setup
    gpio_set_direction(g_led_white, GPIO_MODE_OUTPUT);
    gpio_set_level(g_led_white, 1);

    // Setup
    if (!setup()) {
        printf("Setup failed\n");
        while (true) {
            vTaskDelay(1);
        }
    }

    // White LED off after setup
    gpio_set_level(g_led_white, 0);

    // Select task
    xTaskCreate((TaskFunction_t)&main_task_camera, "main", 32 * 1024, NULL, 8, NULL);
    // xTaskCreate((TaskFunction_t)&main_task_serial, "main", 32 * 1024, NULL, 8, NULL);

    vTaskDelete(NULL);
}
