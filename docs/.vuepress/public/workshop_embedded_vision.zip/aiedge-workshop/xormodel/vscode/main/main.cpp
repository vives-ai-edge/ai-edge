// FreeRTOS and ESP includes
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"

// TFlite Micro includes
#include "tensorflow/lite/micro/micro_error_reporter.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/schema/schema_generated.h"

// Header file for our model
#include "xormodel.h"

// Global pointer for our interpreter
// We build an interpreter in setup() and use it in main_task(), thus needing a global pointer
tflite::MicroInterpreter* g_interpreter = nullptr;


bool setup()
{
    // Setup Logging
    // This is required for TFLite Micro
    static tflite::MicroErrorReporter micro_error_reporter;

    // Load Model
    // The model is defined as a C array, which we generated in the notebook
    const tflite::Model* model = ::tflite::GetModel(xormodel_tflite);
    if (model->version() != TFLITE_SCHEMA_VERSION) {
        printf(
            "Model provided is schema version %d not equal to supported version %d.\n",
            model->version(),
            TFLITE_SCHEMA_VERSION
        );
        return false;
    }

    // Operations Resolver
    // The model definition defines which operation to run and in what order, but this resolver links operations with the correct code to run.
    // TFLite Micro contains a resolver with all operations, but in order to limit code memory and compile time,
    // we can use a MutableOpResolver and specify which operations will be used.
    static tflite::MicroMutableOpResolver<2> resolver;
    resolver.AddFullyConnected();
    resolver.AddLogistic();

    // Allocate Memory
    // Instead of dynamically allocating memory, TFLite Micro works with a static memory pool.
    // All data necessary to run the model will be stored in here.
    // One optimization is to reduce the arena_size to get it as small as possible, whilst still being able to run the model.
    constexpr int tensor_arena_size = 2 * 1024;
    static uint8_t tensor_arena[tensor_arena_size];

    // Interpreter
    // Finally we combine all the objects above into a single TFLite interpreter object.
    static tflite::MicroInterpreter interpreter(
        model,
        resolver,
        tensor_arena,
        tensor_arena_size,
        &micro_error_reporter
    );

    g_interpreter = &interpreter;

    // Allocate Tensors
    // Once the interpreter is build, we can try to allocate memory in our arena, to check whether we reserved enough memory.
    if (interpreter.AllocateTensors() != kTfLiteOk) {
        printf("Allocate tensors failed\n");
        return false;
    }

    return true;
}


void main_task()
{
    // Input & Output
    // These are the objects which we access in order to provide input and read the output from the model.
    TfLiteTensor* input = g_interpreter->input(0);
    TfLiteTensor* output = g_interpreter->output(0);

    // Provide input
    // The data field is a union type, which allows you to pass data as different types.
    // When designing our model we specified the inputs to be floating point values and thus here we access the ".f" union to enter floating point data.
    input->data.f[0] = 0;
    input->data.f[1] = 1;

    // Print operation
    // The input data gets modified whilst running the model so we print it before.
    printf("%.2f XOR %.2f ", input->data.f[0], input->data.f[1]);

    // Run Model
    if (g_interpreter->Invoke() != kTfLiteOk) {
        printf("Invoke failed\n");
        return;
    }

    // Get output
    // Similarly to the input, the output data field is also a union type.
    float output_probability = output->data.f[0];
    bool output_xor = output_probability > 0.5;
    
    // Print result
    printf("= %d  (%.2f %%)\n", output_xor, output_probability * 100);

    // Endless loop
    while (true) {
        vTaskDelay(1);
    }
}


// Main entry point of ESP
extern "C" void app_main()
{
    if (!setup()) {
        printf("Setup failed\n");
        while (true) {
            vTaskDelay(1);
        }
    }

    xTaskCreate((TaskFunction_t)&main_task, "main", 32 * 1024, NULL, 8, NULL);
}
