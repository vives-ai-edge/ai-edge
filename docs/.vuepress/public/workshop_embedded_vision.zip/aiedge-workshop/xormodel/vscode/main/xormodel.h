extern unsigned char xormodel_tflite[];
extern unsigned int xormodel_tflite_len;
